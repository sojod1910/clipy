# app.py
import os
import tempfile
import shutil
import math
from datetime import timedelta
from pathlib import Path
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import yt_dlp
from pydub import AudioSegment
import subprocess
import re

# Optional libs (may be heavy)
try:
    import whisper
except Exception:
    whisper = None

# For optional OpenAI summarization
try:
    import openai
except Exception:
    openai = None

# For local keyword extraction / simple summarization fallback
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize
import nltk
from nltk.tokenize import sent_tokenize
nltk.download('punkt', quiet=True)

app = Flask(__name__)
CORS(app)

# Config via env
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")  # optional
if OPENAI_API_KEY and openai:
    openai.api_key = OPENAI_API_KEY

# Helpers ------------------------------------------------------------------

def sec_to_hms(seconds: float) -> str:
    total = int(seconds)
    td = timedelta(seconds=total)
    return str(td)

def ensure_ffmpeg_installed():
    # quick check
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        return True
    except Exception:
        return False

def download_youtube_audio(url: str, out_dir: str) -> str:
    """
    Downloads best audio from YouTube and returns path to downloaded file (likely m4a/webm).
    Requires yt_dlp and ffmpeg.
    """
    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": os.path.join(out_dir, "yt_audio.%(ext)s"),
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        # postprocessors could be used, but we'll convert ourselves
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        fn = ydl.prepare_filename(info)
    # find actual file (ext may differ)
    base = os.path.join(out_dir, "yt_audio")
    for ext in ("m4a", "mp3", "webm", "wav", "opus", "aac"):
        candidate = f"{base}.{ext}"
        if os.path.exists(candidate):
            return candidate
    # if not found return the prepared filename
    return fn

def save_upload_file(file_storage, out_dir: str) -> str:
    filename = os.path.join(out_dir, file_storage.filename)
    file_storage.save(filename)
    return filename

def to_wav(input_path: str, out_path: str) -> str:
    """
    Convert any audio/video to mono 16k wav using ffmpeg.
    """
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-ac", "1",
        "-ar", "16000",
        "-vn",
        out_path
    ]
    subprocess.run(cmd, check=True)
    return out_path

# Transcription ------------------------------------------------------------

def transcribe_with_whisper(wav_path: str, model_name: str = "small"):
    """
    Uses whisper (if installed) to transcribe and return segments:
    [{start, end, text}, ...]
    """
    if whisper is None:
        raise RuntimeError("whisper package not installed.")
    model = whisper.load_model(model_name)
    result = model.transcribe(wav_path, word_timestamps=False)  # segments have start/end
    segments = []
    for seg in result.get("segments", []):
        segments.append({
            "start": float(seg["start"]),
            "end": float(seg["end"]),
            "text": seg["text"].strip()
        })
    full_text = result.get("text", "")
    return full_text, segments

# Summarization ------------------------------------------------------------

def summarize_with_openai(text: str, mode: str = "short"):
    """
    Use OpenAI (if available) to summarize. mode: short/medium/bullets
    """
    if openai is None or OPENAI_API_KEY is None:
        raise RuntimeError("OpenAI not configured.")
    prompt_map = {
        "short": "Write a concise 1-2 sentence summary of the following text:",
        "medium": "Write a 3-4 sentence readable summary of the following text:",
        "bullets": "Write a short bullet-point summary (5-8 bullets) of the following text:"
    }
    prompt = prompt_map.get(mode, prompt_map["short"]) + "\n\n" + text
    resp = openai.ChatCompletion.create(
        model="gpt-4o-mini" if hasattr(openai, 'ChatCompletion') else "gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        max_tokens=400
    )
    # support different response formats
    if "choices" in resp and len(resp["choices"])>0:
        return resp["choices"][0]["message"]["content"].strip()
    return str(resp)

def local_summarize(text: str, mode: str="short"):
    """
    Simple fallback summarizer: return first sentences for short/medium,
    or split into basic bullets.
    """
    sents = sent_tokenize(text)
    if len(sents) == 0:
        return ""
    if mode == "short":
        return " ".join(sents[:2])
    elif mode == "medium":
        return " ".join(sents[:4])
    else:  # bullets
        bullets = sents[:6]
        return "\n".join([f"- {s}" for s in bullets])

def summarize_text(text: str, mode: str="short"):
    if OPENAI_API_KEY and openai:
        try:
            return summarize_with_openai(text, mode)
        except Exception:
            return local_summarize(text, mode)
    else:
        return local_summarize(text, mode)

# Keyword extraction -------------------------------------------------------

def extract_keywords_tfidf(text: str, top_n: int = 5):
    """
    Simple TF-IDF-based keyword extraction over sentences.
    Returns top_n keywords (not perfect but works offline).
    """
    # Basic tokenization + vectorization on words (unigrams)
    # Preprocessing: lower, remove non-letters
    def simple_clean(s):
        s2 = re.sub(r'[^a-zA-Z0-9\s]', ' ', s)
        return s2.lower()
    cleaned = simple_clean(text)
    # If text too short fallback to most common words
    words = cleaned.split()
    if len(words) < 10:
        freq = {}
        for w in words:
            freq[w] = freq.get(w, 0) + 1
        sorted_words = sorted(freq.items(), key=lambda x: -x[1])
        return [w for w,_ in sorted_words[:top_n]]
    # Use tfidf to get top features
    vectorizer = TfidfVectorizer(ngram_range=(1,2), stop_words='english', max_features=2000)
    X = vectorizer.fit_transform([cleaned])
    scores = X.toarray().flatten()
    features = vectorizer.get_feature_names_out()
    idx_scores = list(zip(range(len(features)), scores))
    idx_scores.sort(key=lambda x: -x[1])
    keywords = []
    for idx, sc in idx_scores[:top_n*3]:
        keywords.append(features[idx])
    # dedupe and limit
    seen = set()
    final = []
    for k in keywords:
        if k not in seen:
            final.append(k)
            seen.add(k)
        if len(final) >= top_n:
            break
    return final

# Timeline mapping ---------------------------------------------------------

def build_timeline(keywords, segments):
    """
    For each keyword, find the earliest segment that contains it (case-insensitive)
    and create {"keyword","time","segment_text"} entries.
    Also build a list of timeline events sorted by time from segments (important sentences)
    """
    kw_timeline = []
    lower_map = {kw.lower(): kw for kw in keywords}
    for kw in keywords:
        found = None
        for seg in segments:
            if kw.lower() in seg["text"].lower():
                found = {
                    "keyword": kw,
                    "time": sec_to_hms(seg["start"]),
                    "text": seg["text"]
                }
                break
        if not found:
            # try partial matches
            for seg in segments:
                for token in kw.split():
                    if token.lower() in seg["text"].lower():
                        found = {
                            "keyword": kw,
                            "time": sec_to_hms(seg["start"]),
                            "text": seg["text"]
                        }
                        break
                if found:
                    break
        if not found:
            found = {"keyword": kw, "time": None, "text": None}
        kw_timeline.append(found)
    # Also create a condensed timeline: pick top segments by length/words as "events"
    events = []
    for seg in segments:
        events.append({
            "time_start": sec_to_hms(seg["start"]),
            "time_end": sec_to_hms(seg["end"]),
            "text": seg["text"]
        })
    # sort by start
    return kw_timeline, events

# Main endpoint ------------------------------------------------------------

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status":"ok", "ffmpeg": ensure_ffmpeg_installed(), "whisper_installed": whisper is not None})

@app.route("/process", methods=["POST"])
def process_video():
    """
    Accepts either:
    - form-data file field named 'file'
    - JSON body with {"youtube_url": "..."}
    Optional parameter: model (whisper model name), keywords_n (int)
    """
    # create working dir
    workdir = tempfile.mkdtemp(prefix="video_proc_")
    try:
        # check ffmpeg
        if not ensure_ffmpeg_installed():
            return jsonify({"error": "ffmpeg is not installed on server"}), 500

        youtube_url = request.form.get("youtube_url") or (request.json.get("youtube_url") if request.is_json else None)
        model_name = request.form.get("model") or (request.json.get("model") if request.is_json else "small")
        keywords_n = int(request.form.get("keywords_n") or (request.json.get("keywords_n") if request.is_json else 5))

        # file upload?
        if 'file' in request.files:
            f = request.files['file']
            input_path = save_upload_file(f, workdir)
        elif youtube_url:
            input_path = download_youtube_audio(youtube_url, workdir)
        else:
            return jsonify({"error": "No file uploaded and no youtube_url provided"}), 400

        # convert to wav 16k mono for whisper
        wav_path = os.path.join(workdir, "audio.wav")
        to_wav(input_path, wav_path)

        # transcribe
        try:
            full_text, segments = transcribe_with_whisper(wav_path, model_name=model_name)
        except Exception as e:
            return jsonify({"error": "Transcription failed", "details": str(e)}), 500

        # summarization
        summary_short = summarize_text(full_text, mode="short")
        summary_medium = summarize_text(full_text, mode="medium")
        summary_bullets = summarize_text(full_text, mode="bullets")

        # keywords
        keywords = extract_keywords_tfidf(full_text, top_n=keywords_n)

        # timeline
        kw_timeline, events = build_timeline(keywords, segments)

        result = {
            "summary_short": summary_short,
            "summary_medium": summary_medium,
            "summary_bullets": summary_bullets,
            "keywords": keywords,
            "keywords_timeline": kw_timeline,
            "events_timeline": events,
            "full_text_preview": full_text[:500] + ("..." if len(full_text)>500 else "")
        }
        return jsonify(result)
    finally:
        # clean up - comment this line if you want to keep files for debugging
        shutil.rmtree(workdir, ignore_errors=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 7860)), debug=True)
